//
//  SGRuleActionButton.h
//  SixgillSDK
//
//  Created by Sanchit Mittal on 27/02/19.
//  Copyright © 2019 Sixgill. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SGRuleActionButton : NSObject
@property (nonatomic, strong) NSString *text;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *message;

- (instancetype)initWithData:(NSDictionary *)data;

@end
