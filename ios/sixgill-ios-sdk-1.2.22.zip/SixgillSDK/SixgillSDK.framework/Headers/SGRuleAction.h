//
//  SGRuleAction.h
//  SixgillSDK
//
//  Created by Sanchit Mittal on 19/12/18.
//  Copyright © 2018 Sixgill. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SGRuleActionButton.h"
#import "SGRuleActionOption.h"

@interface SGRuleAction : NSObject

@property (nonatomic, strong) NSString *message;
@property (nonatomic, strong) NSString *subject;

@property (nonatomic, strong) NSString *body;
@property (nonatomic, strong) NSString *type;
@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *submitUrl;
@property (nonatomic, readwrite) BOOL multipleChoice;
@property (nonatomic, readwrite) NSString *hint;
@property (nonatomic, readwrite) NSString *address;
@property (nonatomic, readwrite) NSString *landmarkId;
@property (nonatomic, readwrite) NSString *addressTitle;
@property (nonatomic, readwrite) BOOL reflect;


@property (nonatomic, strong) NSArray *recipients;
@property (nonatomic, strong) NSArray<SGRuleActionButton *> *actionsButtons;
@property (nonatomic, strong) NSArray<SGRuleActionOption *> *actionsOptions;


@property (nonatomic, strong) NSString *url;
@property (nonatomic, strong) NSString *method;
@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSDictionary<NSString *, NSString *> *headers;

- (instancetype)initWithData:(NSDictionary *)data;

@end
