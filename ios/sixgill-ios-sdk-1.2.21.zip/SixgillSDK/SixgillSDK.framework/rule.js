
'use strict';

var checkConditionForEvent = function(eventString, condition) {
    const event = {payload: JSON.parse(eventString)};
    const isConditionValid = eval(condition)
    return isConditionValid;
}
