//
//  SGRuleActionOption.h
//  SixgillSDK
//
//  Created by Sanchit Mittal on 27/02/19.
//  Copyright © 2019 Sixgill. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SGRuleActionOption : NSObject

@property (nonatomic, strong) NSString *text    ;
@property (nonatomic, readwrite) int64_t value;

- (instancetype)initWithData:(NSDictionary *)data;

@end
