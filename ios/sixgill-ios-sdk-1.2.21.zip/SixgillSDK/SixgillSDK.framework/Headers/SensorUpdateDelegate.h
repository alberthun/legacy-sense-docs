//
//  SensorUpdateDelegate.h
//  SixgillSDK
//
//  Created by Ricky Kirkendall on 6/14/17.
//  Copyright © 2017 Sixgill. All rights reserved.
//

#ifndef SensorUpdateDelegate_h
#define SensorUpdateDelegate_h

#import "Ingress.pbobjc.h"

typedef NS_ENUM(NSInteger, EventNetworkStatus) {
    EventNetworkStatusUnsent,
    EventNetworkStatusRetrying,
    EventNetworkStatusSent
};

@protocol SensorUpdateDelegate

-(void)sensorUpdateSentWithData:(Event *)sensorData;

-(void)updateEventNetworkStatus:(EventNetworkStatus)status forEventTimestamp:(int64_t)timestamp;
@end

#endif /* SensorUpdateDelegate_h */
