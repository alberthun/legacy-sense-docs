//
//  SixgillSDK.h
//  SixgillSDK

//  Created by Ricky Kirkendall on 11/30/16.
//  Copyright © 2016 Sixgill. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SixgillSDK.
FOUNDATION_EXPORT double SixgillSDKVersionNumber;

//! Project version string for SixgillSDK.
FOUNDATION_EXPORT const unsigned char SixgillSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SixgillSDK/PublicHeader.h>

#import <SixgillSDK/SGSDK.h>
#import <SixgillSDK/Ingress.pbobjc.h>
